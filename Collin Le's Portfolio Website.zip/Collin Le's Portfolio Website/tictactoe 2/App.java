import java.applet.*;

public class App extends Applet{
    public static void main(String[] args) {
        TicTacToe game = new TicTacToe();
        
    }
}
